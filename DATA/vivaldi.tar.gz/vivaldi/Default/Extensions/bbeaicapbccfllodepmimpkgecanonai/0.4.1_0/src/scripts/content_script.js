(function () {
  'use strict';

  const utils = {
    sendStorage() {
      window.postMessage({
        from: 'BLOCKTUBE_CONTENT',
        type: 'storageData',
        data: compiledStorage || globalStorage,
      }, document.location.origin);
    },
    inject() {
      const s = document.createElement('script');
      s.src = chrome.extension.getURL('src/scripts/inject.js');
      s.onload = events.ready;
      s.async = false;
      (document.head || document.documentElement).appendChild(s);
    },
    sendReload(msg, duration) {
      window.postMessage({
        from: 'BLOCKTUBE_CONTENT',
        type: 'reloadRequired',
        data: {msg, duration}
      }, document.location.origin);
    }
  };

  if (document.body) {
    utils.sendReload();
    return;
  }

  // Inject seed
  const seed = document.createElement('script');
  seed.textContent = `
  (function(){"use strict";window.btDispatched=false;const isMobileInterface=document.location.hostname.startsWith("m.");function createProxyHook(path,hookKeys){path=path.split(".");function getHandler(nextPath,enableHook){return{get:function(target,key){if(key===nextPath[0]&&typeof target[key]==="object"&&target[key]!==null&&!target[key].isProxy_){nextPath.shift();target[key]=new Proxy(target[key],getHandler(nextPath,nextPath.length==0));target[key].isProxy_=true}return target[key]},set:function(target,key,value){if(enableHook&&hookKeys.includes(key)){function hook_(){if(window.btDispatched)return value.apply(null,arguments);else window.addEventListener("blockTubeReady",value.bind(null,arguments))}target[key]=hook_}else{target[key]=value}return true}}}return new Proxy({},getHandler(path,path.length==1))}const spf_uris=["/browse_ajax","/related_ajax","/service_ajax","/list_ajax","/guide_ajax","/live_chat/get_live_chat"];const fetch_uris=["/youtubei/v1/search","/youtubei/v1/guide","/youtubei/v1/browse","/youtubei/v1/next","/youtubei/v1/player"];const hooks={menuOnTap(...args){window.btExports.menuOnTap.call(this,...args)},menuOnTapMobile(...args){window.btExports.menuOnTapMobile.call(this,...args)},genericHook(cb){return function(...args){if(window.btDispatched){cb.call(this,...args)}else{window.addEventListener("blockTubeReady",(()=>{cb.call(this,...args)}))}}}};function setupPolymer(v){return function(...args){if(!args[0].is){return v(...args)}switch(args[0].is){case"ytd-app":args[0].loadDesktopData_=hooks.genericHook(args[0].loadDesktopData_);break;case"ytd-guide-renderer":args[0].attached=hooks.genericHook(args[0].attached);break;default:break}return v(...args)}}function isUrlMatch(url){if(!(url instanceof URL))url=new URL(url);return spf_uris.some((uri=>uri===url.pathname))||url.searchParams.has("pbj")}function onPart(url,next){return function(resp){if(window.btDispatched){window.btExports.spfFilter(url,resp);next(resp)}else window.addEventListener("blockTubeReady",(()=>{window.btExports.spfFilter(url,resp);next(resp)}))}}function spfRequest(cb){return function(...args){if(args.length<2)return cb.apply(null,args);let url=new URL(args[0],document.location.origin);if(isUrlMatch(url)){args[1].onDone=onPart(url,args[1].onDone);args[1].onPartDone=onPart(url,args[1].onPartDone)}return cb.apply(null,args)}}if(window.writeEmbed||window.ytplayer||window.Polymer){console.error("We may have lost the battle, but not the war");return}const org_fetch=window.fetch;window.fetch=function(resource,init=undefined){if(!(resource instanceof Request)||!fetch_uris.some((u=>resource.url.includes(u)))){return org_fetch(resource,init)}return new Promise(((resolve,reject)=>{org_fetch(resource,init=init).then((function(resp){const url=new URL(resource.url);resp.json().then((function(jsonResp){if(window.btDispatched){window.btExports.fetchFilter(url,jsonResp);resolve(new Response(JSON.stringify(jsonResp)))}else window.addEventListener("blockTubeReady",(()=>{window.btExports.fetchFilter(url,jsonResp);resolve(new Response(JSON.stringify(jsonResp)))}))})).catch(reject)})).catch(reject)}))};if(window.location.pathname.startsWith("/embed/")){const XMLHttpRequestResponse=Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype,"response");Object.defineProperty(XMLHttpRequest.prototype,"response",{get:function(){if(!fetch_uris.some((u=>this.responseURL.includes(u)))){return XMLHttpRequestResponse.get.call(this)}let res=JSON.parse(XMLHttpRequestResponse.get.call(this).replace(")]}'",""));window.btExports.fetchFilter(new URL(this.responseURL),res);return JSON.stringify(res)},configurable:true})}Object.defineProperty(window,"Polymer",{get(){return this._polymer},set(v){if(v instanceof Function){this._polymer=setupPolymer(v)}else{this._polymer=v}},configurable:true,enumerable:true});Object.defineProperty(window,"writeEmbed",{get(){return this.writeEmbed_},set(v){this.writeEmbed_=()=>{if(window.btDispatched)v.apply(this);else window.addEventListener("blockTubeReady",v.bind(this))}}});Object.defineProperty(window,"loadInitialData",{get(){return this.loadInitialData_},set(v){this.loadInitialData_=a1=>{if(window.btDispatched)return v(a1);else window.addEventListener("blockTubeReady",v.bind(this,a1))}}});window.yt=createProxyHook("player.Application",["create","createAlternate"]);document.addEventListener("spfready",(function(e){Object.defineProperty(window.spf,"request",{get(){return this.request_},set(v){this.request_=spfRequest(v)}})}));if(isMobileInterface){class ElementHook extends HTMLElement{connectedCallback(){this.onclick=hooks.menuOnTapMobile;this.ondblclick=hooks.menuOnTapMobile}}class ButtonRendererHook extends ElementHook{}class MenuServiceItemHook extends ElementHook{}class MenuNavigationItemHook extends ElementHook{}class MenuItemHook extends ElementHook{}customElements.define("ytm-button-renderer",ButtonRendererHook);customElements.define("ytm-menu-service-item-renderer",MenuServiceItemHook);customElements.define("ytm-menu-navigation-item-renderer",MenuNavigationItemHook);customElements.define("ytm-menu-item",MenuItemHook)}if(!isMobileInterface){let customElementsRegistryDefine=window.customElements.define;Object.defineProperty(window.customElements,"define",{configurable:true,enumerable:false,value:function(name,constructor){if(name==="ytd-menu-service-item-renderer"){let origCallback=constructor.prototype.connectedCallback;constructor.prototype.connectedCallback=function(){this.onclick=hooks.menuOnTap;origCallback.call(this)}}customElementsRegistryDefine.call(window.customElements,name,constructor)}})}})();
  `;
  seed.async = false;
  (document.head || document.documentElement).prepend(seed);

  let globalStorage;
  let compiledStorage;
  let ready = false;
  let port = null;

  const storage = {
    set(data) {
      chrome.storage.local.set({ storageData: data });
    },
    get(cb) {
      chrome.storage.local.get('storageData', (storageRes) => {
        cb(storageRes.storageData);
      });
    },
  };

  const events = {
    contextBlock(data) {
      const entries = [`// Blocked by context menu (${data.info.text})`];
      const id = Array.isArray(data.info.id) ? data.info.id : [data.info.id];
      entries.push(...id);
      entries.push('');
      globalStorage.filterData[data.type].push(...entries);
      storage.set(globalStorage);
    },
    ready() {
      utils.sendStorage();
      ready = true;
    },
  };

  function connectToPort() {
    port = chrome.runtime.connect();

    // Listen for messages from background page
    port.onMessage.addListener((msg) => {
      switch (msg.type) {
        case 'filtersData': {
          if (msg.data) {
            globalStorage = msg.data.storage;
            compiledStorage = msg.data.compiledStorage;
          }
          if (ready) utils.sendStorage();
          break;
        }
        default:
          break;
      }
    });

    // Reload page on extension update/uninstall
    port.onDisconnect.addListener(() => {
      port = null;
      utils.sendReload();
    });
  }

  connectToPort();

  // Listen for messages from injected page script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (!event.data.from || event.data.from !== 'BLOCKTUBE_PAGE') return;

    switch (event.data.type) {
      case 'contextBlockData': {
        events.contextBlock(event.data.data);
        break;
      }
      default:
        break;
    }
  }, true);

  // Inject script to page
  utils.inject();
}());
