const addFlags = async() => {
    const upperPlayer = document.getElementsByClassName('ruser-top')[0]?.getElementsByClassName('text')[0];
    const upperFlag = await getFlag(upperPlayer);
    if (upperFlag) {
        const upperPlayerFlagImage = createFlagImage(upperFlag);
        upperPlayer.appendChild(upperPlayerFlagImage);
    }

    const lowerPlayer = document.getElementsByClassName('ruser-bottom')[0]?.getElementsByClassName('text')[0];
    const lowerFlag = await getFlag(lowerPlayer);
    if (lowerFlag) {
        const lowerPlayerFlagImage = createFlagImage(lowerFlag);
        lowerPlayer.appendChild(lowerPlayerFlagImage);
    }
};

const createFlagImage = (flag) => {
    console.log(flag.url);
    if (!flag) return;
    let image = document.createElement('img');
    image.src = flag.url;
    image.title = getCountryNameFor(flag.countryCode) || '';
    image.style = 'padding-left: 10px; /*padding-bottom: 10px*/';
    return image;
};

const getFlag = async (element) => {
    const username = getUsername(element);
    if (!username) return '';
    const response = await (await fetch('https://lichess.org/api/user/' + username))?.json();
    const countryCode = response?.profile?.country || '';
    const url = countryCode ? 'https://lichess1.org/assets/_0dhxZ8/images/flags/' + countryCode + '.png' : '';
    return {url: url, countryCode: countryCode};
};

const getUsername = (element) => {
    if (isTitledPlayer(element)) {
        const titledUser = element?.textContent || '';
        return titledUser.replace(/^(GM|WGM|IM|WIM|FM|WFM|CM|WCM)\s+/g, '');
    }
    return element?.textContent || '';
};

const isTitledPlayer = (element) => {
    return element && element.getElementsByClassName('utitle');
};

window.onload = function(){addFlags()};